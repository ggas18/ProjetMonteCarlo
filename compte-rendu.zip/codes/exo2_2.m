% debut de la boucle for pour les Nsim estimations
% estimation du call avec la methode de l'exo2
start=tic;
for n=1:Nsim    
    [I_hat_call_1,err_std_call_1]=monteCarloCall(n*pas);
    I_call_1(n)=I_hat_call_1;
    Err_call_1(n)=err_std_call_1;   
end
t_exo2=toc(start);
% fin de la boucle for pour les Nsim estimations exo2
% debut de la boucle for pour les Nsim estimations
% estimation du call avec la methode de l'exo3
start=tic;
for n=1:Nsim     
    [I_hat_call_2,err_std_call_2]=monteCarloCallExo3(n*pas);
    I_call_2(n)=I_hat_call_2;Err_call_2(n)=err_std_call_2;   
end
t_exo3=toc(start);
% fin de la boucle for pour les Nsim estimations exo3
% affichage des resultats et preparation de la figure
N=pas*(1:Nsim); % vecteur du nombre de simulation
fig_exo2=figure();
title('Exo 3 call seul: question 2 et 3 avec \alpha =0.95')
xlabel('Nombre de simulations')
ylabel('Valeurs des options');hold on
% ajout des temps de calculs
str = {sprintf('temps exo 2: %0.2es',t_exo2),...
       sprintf('temps exo 3: %0.2es',t_exo3)};
text(pas*Nsim*7/14,.5,str)
% affichage du call exact
figEx_call=plot(N,C,'LineWidth',2);% valeur exacte
% affichages pour la methode de l'exo2
figI_call_2=plot(N,I_call_2,'LineWidth',2);% l'estimation
figHaut_call_2=plot(N,I_call_2+Z*Err_call_2,'LineWidth',2);% sup de l'IC
figBas_call_2=plot(N,I_call_2-Z*Err_call_2,'LineWidth',2);%inf de l'IC
% affichage du call par l'exo 1 
figI_call_1=plot(N,I_call_1,'LineWidth',2);% l'estimation
figHaut_call_1=plot(N,I_call_1+Z*Err_call_1,'LineWidth',2);% borne sup de l'IC
figBas_call_1=plot(N,I_call_1-Z*Err_call_1,'LineWidth',2);% borne inf de l'IC
% ajout des legendes a la figure
legend([ figI_call_2, figHaut_call_2, figBas_call_2,...
        figEx_call, figI_call_1, figHaut_call_1, figBas_call_1],...
         'estimation exo3','haute exo3','basse exo3',...
        'exact call', 'estimation exo2','haute exo2','basse exo2');
 % on enregistre la figure sous format jpg
chem='images';chem=strcat(chem,'/exo3');
print(fig_exo2,chem,'-djpeg')