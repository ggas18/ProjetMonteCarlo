 n=1;
 while(n<N)
      X=randn();% on une normale centree reduite
      Y_1=max(exp(beta*X)-K,0);% antithetique 1
      Y_2=max(exp(-beta*X)-K,0);% antithetique 2
      S1_1=S1_1+Y_1;    % mise-a-jour de S1_1
      S2_1=S2_1+Y_1^2;  % mise-a-jour de S2_1 
      S1_2=S1_2+Y_2;    % mise-a-jour de S1_2
      S2_2=S2_2+Y_2^2;  % mise-a-jour de S2_2 
      m_y1y2= m_y1y2+Y_1*Y_2;% mise-a-jour de m_y1y2
      n=n+1; 
 end
 % on estime la variance par son estimateur sans biais
 % pour la v.a Y1
 v_1=(S2_1-N*(S1_1/N)^2)/(N-1);
 % on estime la variance par son estimateur sans biais
 % pour la v.a Y2
 v_2=(S2_2-N*(S1_2/N)^2)/(N-1);
 % la covariance
 cov1_2=(m_y1y2-(S1_1*S1_2)/N)/(N-1);
 % variance et ecart-type finaux est
 variance=v_1/4+v_2/4+cov1_2/2;
 s=sqrt(variance);
 % on retourne l'estimation obtenue.
 I_hat=(S1_1+S1_2)/(2*N);
 % on retourne l'erreur standard de cette simulation
 err_std=s/sqrt(N);
end