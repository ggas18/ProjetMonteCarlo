%% monte carlo pour l'exercice 4
clc;close all
% le quantile d'ordre (alpha+1)/2 de la loi normale
% centree reduite.
alpha=.95;
Z=norminv((alpha+1)/2,0,1); 
% pas et nombre d'estimations des options.
Nsim=100;pas=200;
% on initialise le vecteur des estimations
% et des erreurs. Pour trouver l'intervalle
% de confiance plus tard il suffirat d'uti-
% liser IC=[I-Z*s/sqrt(n),I+Z*s/sqrt(n)]
I_put=zeros(1,Nsim);
Err_put=I_put;
I_call_1=zeros(1,Nsim);
Err_call_1=I_call_1;
I_call_2=zeros(1,Nsim);
Err_call_2=I_call_2;
I_call_3=zeros(1,Nsim);
Err_call_3=I_call_3;
I_call_4=zeros(1,Nsim);
Err_call_4=I_call_4;
% parametres des options
K=1;beta=1;
% les valeurs exactes des options
C_ex=(exp(beta^2/2)*normcdf(beta-log(K)/beta,0,1)-...
    K*normcdf(-log(K)/beta,0,1));
C=C_ex*ones(1,Nsim);
% on augmente le nombre d'echantillons de pas a chaque
% fois pour obtenir Nsim simulation de chaque option
% debut de la boucle for pour les Nsim estimations
% estimation du call avec la methode de l'exo2
start=tic;
for n=1:Nsim    
    [I_hat_call_1,err_std_call_1]=monteCarloCall(n*pas);
    I_call_1(n)=I_hat_call_1;
    Err_call_1(n)=err_std_call_1;   
end
t_exo2=toc(start);
% fin de la boucle for pour les Nsim estimations exo2
% debut de la boucle for pour les Nsim estimations
% estimation du call avec la methode de l'exo3
start=tic;
for n=1:Nsim     
    [I_hat_call_2,err_std_call_2]=monteCarloCallExo2(n*pas);
    I_call_2(n)=I_hat_call_2;Err_call_2(n)=err_std_call_2;   
end
t_exo3=toc(start);
% fin de la boucle for pour les Nsim estimations exo3