function [I_hat,err_std]=monteCarloCallExo5(N)
  % Cette fonction fait une simulation de Monte en
  % N echantillons en utilisant la symetrie de la
  % loi normale centree reduite pour faire des v.a
  % antithetiques
  % ENTREE : N: Le nombre de simulation      
  % SORTIE : I_hat: La valeur approchee du call 
  %          err_std: Erreur standard de la simulation realisee
  %                   parametre du call
  beta=1;K=1;
  X= randn(); % simulation d'une variable de loi normale
  % centree reduite
  Y_1=max(exp(beta*X)-K,0);% antithetique 1
  Y_2=max(exp(-beta*X)-K,0);% antithetique 2
  S1_1=Y_1; % somme partielle des Y1i
  S2_1=Y_1^2; % somme patielle des Y1i^2
  S1_2=Y_2; % somme partielle des Y2i
  S2_2=Y_2^2; % somme patielle des Y2i^2
  m_y1y2=Y_1*Y_2;% la somme des produits des Y1i*Y2i
  % utile pour calculer la covariance